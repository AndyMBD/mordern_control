# Resources
The model for the related motor control issues
* Add TI offical code for sliding mode oberver and PI regulator with anti-windup
* Add Inverter with deadtime model

I will push more codes here in the near future.
